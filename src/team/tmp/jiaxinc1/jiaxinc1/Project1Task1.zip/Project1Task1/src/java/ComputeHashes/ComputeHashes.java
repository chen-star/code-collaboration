/*
 * Author: Jiaxin Chen
 * Last Modified: Sep 10, 2018
 * 
 * This servlet class implements hash encoding function.
 * Get user input from text area on the page,
 * return the hashed value of the input text
 */
package ComputeHashes;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.*;
import java.security.*;
import javax.servlet.RequestDispatcher;
import sun.security.jgss.GSSToken;
import javax.xml.bind.*;

/**
 *
 * @author chenjiaxin
 */
@WebServlet(name = "ComputeHashes",
        urlPatterns = {"/"})
public class ComputeHashes extends HttpServlet {

    // doGet() method is to return the index home page
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // return index page
        RequestDispatcher view = request.getRequestDispatcher("index.jsp");
        view.forward(request, response);
    }

    // doPost() method is to return hashed value page
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // get raw data from request
        String rawData = request.getParameter("rawData");
        // get which hash method has been selected
        String hashSelection = request.getParameter("hashSelection");
        // set return name attribute
        String name = hashSelection;
        // init return hexValue attribute
        String hexValue = null;
        // init return baseValue attribute
        String baseValue = null;

        // if user select MD5
        if (hashSelection.equals("MD5")) {
            try {
                // use API to do hash
                MessageDigest md = MessageDigest.getInstance("MD5");
                md.update(rawData.getBytes());
                byte[] bytes = md.digest();
                // get hex form
                hexValue = getHex(bytes);
                // get base64 form
                baseValue = getBase(bytes);
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else { // if user select SHA-256
            try {
                // use API to do hash
                MessageDigest md = MessageDigest.getInstance("SHA-256");
                md.update(rawData.getBytes());
                byte[] bytes = md.digest();
                // get hex form
                hexValue = getHex(bytes);
                // get base64 form
                baseValue = getBase(bytes);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // set all required attributs to request
        request.setAttribute("hex", hexValue);
        request.setAttribute("base64", baseValue);
        request.setAttribute("name", name);
        request.setAttribute("rawData", rawData);
        // send response to index page
        RequestDispatcher view = request.getRequestDispatcher("/index.jsp");
        view.forward(request, response);
    }

    // return hex form of hashed value
    private String getHex(byte[] hexBytes) {
        return DatatypeConverter.printHexBinary(hexBytes);
    }
    
    // return base64 form of hashed value
    private String getBase(byte[] baseBytes) {
        return DatatypeConverter.printBase64Binary(baseBytes);
    }

}
