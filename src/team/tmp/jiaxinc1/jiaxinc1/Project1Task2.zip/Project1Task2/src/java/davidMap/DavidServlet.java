/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package davidMap;

import java.io.IOException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This class is a Servlet used to handled user request.
 * User will input a city and year period for the search.
 * 
 * @author chenjiaxin
 */
public class DavidServlet extends HttpServlet {
//     https://www.davidrumsey.com/luna/servlet/view/search?search=SUBMIT&q=london&dateRangeStart=1000&dateRangeEnd=2000&sort=pub_list_no_initialsort%2Cpub_date%2Cpub_list_no%2Cseries_no&QuickSearchA=QuickSearchA

    // The "business model" for this app
    PictureModel pic = null;  

    // Initiate this servlet by instantiating the model that it will use.
    @Override
    public void init() {
        pic = new PictureModel();
    }

    // This servlet will reply to HTTP GET requests via this doGet method
    @Override
    protected void doGet(HttpServletRequest request,
            HttpServletResponse response)
            throws ServletException, IOException {

        // get the city parameter if it exists
        String city = request.getParameter("city");
        // get the start year parameter if it exists
        String startYear = request.getParameter("startYear");
        // get the end year parametr if it exitss
        String endYear = request.getParameter("endYear");

        // determine what type of device our user is
        String ua = request.getHeader("User-Agent");

        boolean isMobile;
        // prepare the appropriate DOCTYPE for the view pages
        if (ua != null && ((ua.indexOf("Android") != -1) || (ua.indexOf("iPhone") != -1))) {
            isMobile = true;
            /*
             * This is the latest XHTML Mobile doctype. To see the difference it
             * makes, comment it out so that a default desktop doctype is used
             * and view on an Android or iPhone.
             */
            request.setAttribute("doctype", "<!DOCTYPE html PUBLIC \"-//WAPFORUM//DTD XHTML Mobile 1.2//EN\" \"http://www.openmobilealliance.org/tech/DTD/xhtml-mobile12.dtd\">");
        } else {
            isMobile = false;
            request.setAttribute("doctype", "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.01 Transitional//EN\" \"http://www.w3.org/TR/html4/loose.dtd\">");
        }

        String nextView;
        /*
         * Check if the search parameter is present.
         * If not, then give the user instructions and prompt for a search string.
         * If there is a search parameter, then do the search and return the result.
         */
        if (city != null) {
            String picSize = (isMobile) ? "mobile" : "desktop";
            // use model to do the search and choose the result view
            String picUrl = pic.getPicUrl(city, startYear, endYear, picSize);

            // if the website is down
            if (picUrl.equals("noNetwork")) {
                nextView = "noNetwork.jsp";
            } // if no picture has been found
            else if (picUrl.equals("noPic")) {
                // set all request attributes for showing jsp page
                request.setAttribute("city", city);
                request.setAttribute("startYear", startYear);
                request.setAttribute("endYear", endYear);
                request.setAttribute("picURL", "noPic");
                nextView = "result.jsp";
            } // randomly select one picture to display
            else {
                // set all request attributes for showing jsp page
                String[] li = picUrl.split("\t");
                request.setAttribute("city", city);
                request.setAttribute("startYear", startYear);
                request.setAttribute("endYear", endYear);
                request.setAttribute("picURL", li[0]);
                request.setAttribute("title", li[1]);
                request.setAttribute("year", li[2]);
                nextView = "result.jsp";
            }
        } else {
            // no city parameter so choose the index view
            nextView = "index.jsp";
        }
        // Transfer control over the the correct "view"
        RequestDispatcher view = request.getRequestDispatcher(nextView);
        view.forward(request, response);
    }
}
