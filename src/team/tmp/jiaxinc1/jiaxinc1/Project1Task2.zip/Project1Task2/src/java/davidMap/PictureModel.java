/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package davidMap;

import com.sun.tools.ws.processor.generator.Names;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import javax.net.ssl.SSLHandshakeException;
import javax.servlet.http.Cookie;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

/**
 * The business model for picture
 *
 * @author chenjiaxin
 */
public class PictureModel {

    /*
     * Get the required url, title and year randomly
     * 
     * Arguments
     * @param city the city want to search
     * @param startYear want to search
     * @param endYear want to search
     * @param picture size based on device
     * @return The URL an image of appropriate size.
     */
    public String getPicUrl(String city, String startYear, String endYear, String picSize) {
        try {
            // get a list of urls
            List<String> pics = getPicUrls(city, startYear, endYear, picSize);
            // if the source website is down or network issue
            if (pics.size() == 1 && pics.get(0).equals("noNetwork")) {
                return "noNetwork";
            }
            // if there is no picture for this city
            if (pics.size() == 0) {
                return "noPic";
            }
            // randomly pick a picture
            String url = pickRandom(pics);
            //System.out.println(url);
            return url;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "noNetwork";
    }

    /*
     * Get the a list of urls
     * 
     * Arguments
     * @param city the city want to search
     * @param startYear want to search
     * @param endYear want to search
     * @param picture size based on device
     * @return The URL an image of appropriate size.
     */
    public List<String> getPicUrls(String city, String startYear, String endYear, String picSize) throws UnsupportedEncodingException {
        /*
         * URL encode the city, e.g. to encode spaces as %20
         *
         */
        city = URLEncoder.encode(city, "UTF-8");
        // StringBuilder for building the url string
        StringBuilder sb = new StringBuilder();
        sb.append("https://www.davidrumsey.com/luna/servlet/view/search?search=SUBMIT&q=");
        sb.append(city);
        sb.append("&dateRangeStart=");
        sb.append(startYear);
        sb.append("&dateRangeEnd=");
        sb.append(endYear);
        sb.append("&sort=pub_list_no_initialsort%2Cpub_date%2Cpub_list_no%2Cseries_no&QuickSearchA=QuickSearchA");
        String searchRequest = sb.toString();

        // Get document object for continuning get urls
        Document document = getResponse(searchRequest);
        // Get a list of img urls by parse document
        List<String> imgUrls = parseDoc(document);
        // if searched pictures <= 50
        if (imgUrls.isEmpty() || imgUrls.size() <= 50) {
            return resize(imgUrls, picSize);
        } // if searched pictures > 50
        else {
            // search more pictures
            //https://www.davidrumsey.com/luna/servlet/view/search?q=london&dateRangeStart=1000&dateRangeEnd=2000&sort=pub_list_no_initialsort%2Cpub_date%2Cpub_list_no%2Cseries_no&os=50
            //https://www.davidrumsey.com/luna/servlet/view/search?q=london&dateRangeStart=1000&dateRangeEnd=2000&sort=pub_list_no_initialsort%2Cpub_date%2Cpub_list_no%2Cseries_no&os=100
            sb = new StringBuilder();
            sb.append("https://www.davidrumsey.com/luna/servlet/view/search?search=SUBMIT&q=");
            sb.append(city);
            sb.append("&dateRangeStart=");
            sb.append(startYear);
            sb.append("&dateRangeEnd=");
            sb.append(endYear);
            sb.append("&sort=pub_list_no_initialsort%2Cpub_date%2Cpub_list_no%2Cseries_no&os=50");
            searchRequest = sb.toString();
            Document next = getResponse(searchRequest);
            imgUrls.addAll(parseDoc(next));
            return resize(imgUrls, picSize);
        }
    }

    /*
     * By passing a search url, get the document object
     * 
     * Arguments
     * @param urlStr the url want to be search
     * @return The document object
     */
    private Document getResponse(String urlStr) {
        Document document = null;
        try {
            document = Jsoup.connect(urlStr).timeout(30000).get();
        } catch (Exception e) {
            System.out.println(e);
        }
        return document;
    }

    /*
     * By passing a document object, get a list of urls
     * 
     * Arguments
     * @param document the document want to parse
     * @return a list of url
     */
    private List<String> parseDoc(Document document) {
        // result list 
        List<String> result = new ArrayList<>();
        // select all elements with [src]
        Elements imgEles = document.select("[src]");
        // iterate all image element
        for (Element imgEle : imgEles) {
            if (imgEle.tagName().equals("img")) {
                // get img the parent element of image element
                Element parent = imgEle.parent();
                // get title element
                Element titleEle = parent.nextElementSibling().nextElementSibling();
                // get year element
                Element yearEle = titleEle.nextElementSibling();
                // process the title
                int ind = titleEle.attr("title").indexOf("-");
                String title = null;
                if (ind == -1) {
                    title = titleEle.attr("title");
                } else {
                    title = titleEle.attr("title").substring(ind + 1);
                }
                //System.out.println(yearEle.text());
                //System.out.println(imgEle.attr("abs:src")+"\t"+titleEle.text()+"\t"+yearEle.text());
                result.add(imgEle.attr("abs:src") + "\t" + title + "\t" + yearEle.text());
            } else {
                //print(" * %s: <%s>", imgEle.tagName(), imgEle.attr("abs:imgEle"));
            }
        }
        return result;
    }

    /*
     * resize the list of imgs
     * 
     * Arguments
     * @param the list of urls
     * @param the picture size
     * @return a list of resized urls
     */
    private List<String> resize(List<String> imgs, String picSize) {
        if (imgs.isEmpty()) {
            return imgs;
        }
        List<String> result = new ArrayList<>();
        //System.out.println(imgs.size());
        for (String imgUrl : imgs) {
            //System.out.println(imgUrl);
            if (imgUrl == null || imgUrl.length() == 0) {
                continue;
            }
            int Sindex = imgUrl.indexOf('S');
            //System.out.println(imgUrl);
            String sizeLetter = (picSize.equals("mobile")) ? "2" : "4";
            // reconstruct the url by changing Size
            StringBuilder sb = new StringBuilder();
            sb.append(imgUrl.substring(0, Sindex));
            sb.append("Size" + sizeLetter);
            sb.append(imgUrl.substring(Sindex + 5));
            //System.out.println(sb.toString());
            result.add(sb.toString());
        }
        //System.out.println(result.size());
        return result;
    }

     /*
     * randomly select a url
     * 
     * Arguments
     * @param urls a list of urls
     * @return randomly selected url
     */
    private String pickRandom(List<String> urls) {
        if (urls.size() == 0) {
            return "noPic";
        }
        Random rd = new Random();
        int max = urls.size();
        int ind = rd.nextInt(max);
        return urls.get(ind);
    }

    // For Test
//    public static void main(String[] args) {
//        PictureModel model = new PictureModel();
//        String url = "https://www.davidrumsey.com/luna/servlet/view/search?q=london&dateRangeStart=1000&dateRangeEnd=2000&sort=pub_list_no_initialsort%2Cpub_date%2Cpub_list_no%2Cseries_no&os=50\n";
//        Document document = model.getResponse(url);
//        model.parseDoc(document);
//    }
}
