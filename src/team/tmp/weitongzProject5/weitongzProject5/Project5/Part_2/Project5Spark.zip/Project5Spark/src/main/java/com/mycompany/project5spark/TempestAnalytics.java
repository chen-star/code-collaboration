/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.project5spark;

import org.apache.spark.SparkConf;
import org.apache.spark.api.java.JavaPairRDD;
import org.apache.spark.api.java.JavaRDD;
import org.apache.spark.api.java.JavaSparkContext;
import scala.Tuple2;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Weitong
 */
public class TempestAnalytics {

    public static void main(String[] args) {
        // basic set ups
        String fileName = "TheTempest.txt";
        SparkConf sparkConf = new SparkConf().setMaster("local").setAppName("Task0");
        JavaSparkContext sparkContext = new JavaSparkContext(sparkConf);
        // read the input file
        JavaRDD<String> inputFile = sparkContext.textFile(fileName);
        // execute task0~5
        task0(inputFile);
        task1(inputFile);
        task2(inputFile);
        task3(inputFile);
        task4(inputFile);
        task5(inputFile);
    }

    /**
     * Using the count method of the JavaRDD class, display the number of lines
     * in "The Tempest".
     *
     * @param fileName
     */
    private static void task0(JavaRDD<String> inputFile) {
        System.out.println("Task0 (number of lines): " + inputFile.count());
        // output is
        // Task0 (number of lines): 3466
    }

    /*
     * Using the split method of the java String class 
        and the flatMap method of the JavaRDD class
        use the count method of the JavaRDD class 
        to display the number of words in The Tempest
     * @param fileName
     */
    private static void task1(JavaRDD<String> inputFile) {
        // split the file on " "
        JavaRDD<String> wordsFromFile = inputFile.flatMap(content
                -> Arrays.asList(content.split(" ")));
        // and count for total numbers
        System.out.println("Task1 (number of words): " + wordsFromFile.count());
        // output is 
        // Task1 (number of words): 19064
    }

    /**
     * Using some of the work you did above and the JavaRDD distinct() and count() methods, display
        the number of distinct words in The Tempest.
     * @param inputFile 
     */
    private static void task2(JavaRDD<String> inputFile) {
        // split the file on " "
        JavaRDD<String> wordsFromFile = inputFile.flatMap(content
                -> Arrays.asList(content.split(" ")));
        // use distinct for distinct numbers
        System.out.println("Task2 (number of distinct words): " + wordsFromFile.distinct().count());
        // output is 
        // Task2 (number of distinct words): 5193
    }

    /**
     * Using the JavaPairRDD class and the saveAsTextFile() method along with the JavaRDD class
    and the mapToPair() method, show each word paired with the digit 1 in the output directory
    named Project5/Part_2/TheTempestOutputDir1. You may re-use RDD's from the above tasks if 
    appropriate.
     * @param inputFile 
     */
    private static void task3(JavaRDD<String> inputFile){
        // split the file on " "
        JavaRDD<String> wordsFromFile = inputFile.flatMap(content
                -> Arrays.asList(content.split(" ")));
        // pair with 1 for each word
        JavaPairRDD<String, Integer> countWord = wordsFromFile.mapToPair(t -> new Tuple2(t, 1));
        // save to text files (_SUCCESS and part-00000)
        countWord.saveAsTextFile("Project5/Part_2/TheTempestOutputDir1");
        // see output in the folder, ~/Project5Spark/Project5/Part_2 and also Project5/Part_2
    }
    
    /**
     * Using work from above and the JavaPairRDD from Task 3, create a new JavaPairRDD with the 
        reduceByKey() method. Save the RDD using the saveAsTextFile() method and place the result in 
        the output directory named Project5/Part_2/TheTempestOutputDir2
     * @param inputFile 
     */
    private static void task4(JavaRDD<String> inputFile){
        // split the file on " "
        JavaRDD<String> wordsFromFile = inputFile.flatMap(content
                -> Arrays.asList(content.split(" ")));
        // pair with 1 for each word and then reduce for the total number
        JavaPairRDD<String, Integer> countWord = wordsFromFile.mapToPair(t -> new Tuple2(t, 1))
                .reduceByKey((x, y) -> (int) x + (int) y);
        // save to text files (_SUCCESS and part-00000)
        countWord.saveAsTextFile("Project5/Part_2/TheTempestOutputDir2");
        // see output in the folder, ~/Project5Spark/Project5/Part_2 and also Project5/Part_2
    
    }
    
    /**
     * Using work from above and the JavaRDD foreach() method, prompt the user for a string and
    then perform a search on every line of the The Tempest. If any line of The Tempest
    contains the String entered by the user then display the entire line. For the display, 
    use System.out.println().
     * @param inputFile 
     */
    private static void task5(JavaRDD<String> inputFile){
        // prompt for a string
        final String s;
        Scanner sc;
        try{
            System.out.println("Enter the word to search in file:");
            // read in the user input
            sc = new Scanner(System.in);
            s = sc.nextLine();
            // search for the string in everyline of text file
            // if it contains the word (s), print
            inputFile.foreach(line -> {if(line.contains(s)) System.out.println(line);});
            sc.close();
        }catch(Exception ex){
        }
        
        
        
    }
}
